# PersonalAuction – Minecraft Java 26.2 / Fabric

Dieses Projekt ist ein **erster Entwicklungsstand (MVP)**. Es enthält die Basis für Auktionen über Scoreboard-Geld und die Befehle `/auction`, `/auction create`, `/auction bid` und `/auction admin`.

## Voraussetzungen
- Minecraft Java 26.2
- Fabric Loader 0.19.3 oder neuer
- Fabric API 0.161.0+26.2
- Java 25
- Gradle 9.5.1

## Admin eintragen
Öffne `PersonalAuction.java` und trage deine Minecraft-UUID in `ADMINS` ein:

```java
private static final Set<UUID> ADMINS = Set.of(
    UUID.fromString("DEINE-UUID-HIER")
);
```

Ohne eingetragene UUID kann kein Spieler Auktionen erstellen.

## Scoreboard-Geld
Das Mod erwartet ein vorhandenes Scoreboard-Objective mit dem Namen `money`. Beispiel:

```mcfunction
/scoreboard objectives add money dummy
/scoreboard players set Spielername money 10000
```

## Befehle
- `/auction` – listet aktive und beendete Auktionen auf
- `/auction create <startpreis> <dauerMinuten>` – erstellt eine Auktion mit dem Item in deiner Haupthand
- `/auction bid <id> <gebot>` – bietet auf eine Auktion
- `/auction admin` – zeigt den Admin-Hinweis

## Wichtige Einschränkungen dieses MVP
- Noch **kein grafisches Inventar-GUI**; die Auktionen werden vorerst im Chat angezeigt.
- Auktionen werden aktuell nur im Arbeitsspeicher gehalten und überstehen keinen Serverneustart noch nicht.
- Die automatische Abschlussmeldung wird derzeit beim nächsten Zugriff auf eine abgelaufene Auktion ausgelöst; ein periodischer Server-Tick-Abschluss ist noch nicht ergänzt.
- Für produktiven Serverbetrieb müssen Gebotsreservierung, Offline-Spieler-Gutschriften und Item-Auslieferung weiter abgesichert werden.

Das Projekt ist deshalb ein Quellcode-Grundgerüst und noch kein fertig getestetes Server-Release. Die API-Namen können beim ersten Gradle-Build für 26.2 noch Anpassungen benötigen.

## Bauen
Im Projektordner:

```bash
gradle build
```

Die fertige Mod-JAR liegt danach unter `build/libs/`.
